<?php
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../db.php';
require_admin();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { http_response_code(400); exit('ID laporan tidak valid.'); }
$stmt = $pdo->prepare('SELECT * FROM reports WHERE id = ?');
$stmt->execute([$id]);
$report = $stmt->fetch();
if (!$report) { http_response_code(404); exit('Laporan tidak ditemukan.'); }
$flash = get_flash();
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Detail Laporan | Ruang Aman</title><link rel="stylesheet" href="../style.css"></head>
<body><header class="admin-header"><div class="wrap admin-nav"><a class="brand" href="../index.php">🛡️ RUANG AMAN</a><a class="nav-link" href="index.php">← Dashboard</a></div></header>
<main class="wrap admin-main"><div class="panel detail-panel"><span class="eyebrow blue">DETAIL LAPORAN #<?= (int)$report['id'] ?></span><h1><?= e($report['category']) ?></h1>
<?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<div class="detail-grid">
<div><span class="detail-label">Tanggal dan waktu kejadian</span><p><?= e(date('d/m/Y H:i', strtotime($report['incident_at']))) ?></p></div>
<div><span class="detail-label">Lokasi umum</span><p><?= e($report['location']) ?></p></div>
<div><span class="detail-label">Waktu laporan diterima</span><p><?= e(date('d/m/Y H:i', strtotime($report['created_at']))) ?></p></div>
<div><span class="detail-label">Pelapor</span><p><?= $report['is_anonymous'] ? 'Anonim' : 'Tidak anonim' ?></p></div>
<?php if (!$report['is_anonymous']): ?>
<div><span class="detail-label">Nama</span><p><?= e($report['reporter_name'] ?: 'Tidak diisi') ?></p></div>
<div><span class="detail-label">Kontak</span><p><?= e($report['reporter_contact'] ?: 'Tidak diisi') ?></p></div>
<?php endif; ?>
</div>
<div class="chronology"><span class="detail-label">Kronologi</span><p><?= nl2br(e($report['chronology'])) ?></p></div>
<form action="update_status.php" method="post" class="status-form">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="id" value="<?= (int)$report['id'] ?>">
<label for="status">Status tindak lanjut</label><select id="status" name="status"><?php foreach (['Menunggu','Diproses','Selesai'] as $s): ?><option value="<?= e($s) ?>" <?= $report['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select>
<button class="button" type="submit">Simpan Status</button>
</form>
</div></main></body></html>
