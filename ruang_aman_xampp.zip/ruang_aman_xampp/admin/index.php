<?php
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../db.php';
require_admin();
$flash = get_flash();
$filter = $_GET['status'] ?? '';
$validStatuses = ['Menunggu', 'Diproses', 'Selesai'];
if (in_array($filter, $validStatuses, true)) {
    $stmt = $pdo->prepare('SELECT id, category, incident_at, location, is_anonymous, status, created_at FROM reports WHERE status = ? ORDER BY created_at DESC LIMIT 300');
    $stmt->execute([$filter]);
} else {
    $stmt = $pdo->query('SELECT id, category, incident_at, location, is_anonymous, status, created_at FROM reports ORDER BY created_at DESC LIMIT 300');
}
$reports = $stmt->fetchAll();
$counts = $pdo->query("SELECT COUNT(*) total, SUM(status='Menunggu') waiting, SUM(status='Diproses') processing, SUM(status='Selesai') done FROM reports")->fetch();
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Dashboard Admin | Ruang Aman</title><link rel="stylesheet" href="../style.css"></head>
<body>
<header class="admin-header"><div class="wrap admin-nav"><a class="brand" href="../index.php">🛡️ RUANG AMAN</a><div>Admin: <?= e($_SESSION['admin_username'] ?? '') ?><form action="logout.php" method="post" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><button class="logout-btn">Keluar</button></form></div></div></header>
<main class="wrap admin-main"><div class="section-heading"><div><span class="eyebrow blue">PANEL PETUGAS</span><h1>Dashboard Laporan</h1><p class="muted">Periksa laporan dan perbarui status tindak lanjutnya.</p></div></div>
<?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<div class="stats">
<div class="stat"><span>Total laporan</span><strong><?= (int)$counts['total'] ?></strong></div>
<div class="stat"><span>Menunggu</span><strong><?= (int)$counts['waiting'] ?></strong></div>
<div class="stat"><span>Diproses</span><strong><?= (int)$counts['processing'] ?></strong></div>
<div class="stat"><span>Selesai</span><strong><?= (int)$counts['done'] ?></strong></div>
</div>
<section class="panel">
<div class="section-heading"><div><h2>Daftar laporan</h2><p class="muted">Maksimal 300 laporan terbaru ditampilkan.</p></div>
<form method="get" class="filter-form"><select name="status"><option value="">Semua status</option><?php foreach ($validStatuses as $s): ?><option value="<?= e($s) ?>" <?= $filter === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select><button class="button button-small">Filter</button></form></div>
<?php if (!$reports): ?><div class="empty">Belum ada laporan untuk filter ini.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>No.</th><th>Jenis</th><th>Waktu kejadian</th><th>Lokasi</th><th>Pelapor</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($reports as $r): ?><tr>
<td>#<?= (int)$r['id'] ?></td><td><?= e($r['category']) ?></td><td><?= e(date('d/m/Y H:i', strtotime($r['incident_at']))) ?></td><td><?= e($r['location']) ?></td><td><?= $r['is_anonymous'] ? 'Anonim' : 'Tidak anonim' ?></td><td><span class="status status-<?= strtolower($r['status']) ?>"><?= e($r['status']) ?></span></td><td><a class="text-link" href="detail.php?id=<?= (int)$r['id'] ?>">Detail →</a></td>
</tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>
</section>
<p class="small-note">Jaga kerahasiaan laporan. Akses dashboard hanya untuk petugas yang ditunjuk sekolah.</p>
</main></body></html>
