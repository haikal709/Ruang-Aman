<?php
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../db.php';
if (is_admin()) { header('Location: index.php'); exit; }
$error = '';
$flash = get_flash();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT id, username, password_hash FROM admins WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $admin = $stmt->fetch();
    if ($admin && password_verify($password, $admin['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        header('Location: index.php');
        exit;
    }
    $error = 'Username atau password tidak sesuai.';
}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Login Admin | Ruang Aman</title><link rel="stylesheet" href="../style.css"></head>
<body class="plain-page"><main class="panel narrow">
<a class="back-link" href="../index.php">← Kembali ke website</a><span class="eyebrow blue">AREA PETUGAS</span><h2>Login Admin</h2><p class="muted">Masuk untuk melihat dan menindaklanjuti laporan.</p>
<?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<label>Username</label><input name="username" required autocomplete="username">
<label>Password</label><input name="password" type="password" required autocomplete="current-password">
<button class="button" type="submit">Masuk</button>
</form></main></body></html>
