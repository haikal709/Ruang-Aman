<?php
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../db.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
verify_csrf();
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$status = $_POST['status'] ?? '';
$allowed = ['Menunggu', 'Diproses', 'Selesai'];
if (!$id || !in_array($status, $allowed, true)) {
    set_flash('Data status tidak valid.', 'error');
    header('Location: index.php');
    exit;
}
$stmt = $pdo->prepare('UPDATE reports SET status = ? WHERE id = ?');
$stmt->execute([$status, $id]);
set_flash('Status laporan berhasil diperbarui.');
header('Location: detail.php?id=' . $id);
exit;
