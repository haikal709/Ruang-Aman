<?php
require_once __DIR__ . '/functions.php';
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ruang Aman | Laporan Sekolah</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="hero">
  <nav class="nav wrap"><a class="brand" href="index.php">🛡️ RUANG AMAN</a><a class="nav-link" href="admin/login.php">Login Admin</a></nav>
  <div class="wrap hero-content">
    <span class="eyebrow">LINGKUNGAN SEKOLAH YANG AMAN</span>
    <h1>Berani melapor.<br><span>Bersama jaga sekolah.</span></h1>
    <p>Sampaikan laporan perundungan atau tawuran agar petugas sekolah yang berwenang dapat menindaklanjutinya secara tepat.</p>
    <a class="button button-light" href="#form-laporan">Buat Laporan ↓</a>
  </div>
</header>
<main class="wrap main-grid">
  <section class="panel form-panel" id="form-laporan">
    <div class="section-heading"><div><span class="eyebrow blue">FORMULIR</span><h2>Kirim Laporan</h2><p class="muted">Isi informasi yang kamu ketahui dengan jujur dan jelas.</p></div><span class="pill">🔒 Privasi dijaga</span></div>
    <?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
    <form action="simpan_laporan.php" method="post">
      <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
      <label for="category">Jenis kejadian <span class="required">*</span></label>
      <select id="category" name="category" required>
        <option value="">Pilih jenis laporan</option>
        <option value="Perundungan">Perundungan (bullying)</option>
        <option value="Tawuran">Tawuran / perkelahian antarkelompok</option>
        <option value="Lainnya">Lainnya / belum yakin</option>
      </select>

      <label for="incident_at">Tanggal dan waktu kejadian <span class="required">*</span></label>
      <input id="incident_at" name="incident_at" type="datetime-local" required>

      <label for="location">Lokasi umum kejadian <span class="required">*</span></label>
      <input id="location" name="location" type="text" maxlength="120" placeholder="Contoh: koridor lantai 2 atau sekitar lapangan" required>

      <label for="chronology">Kronologi kejadian <span class="required">*</span></label>
      <textarea id="chronology" name="chronology" maxlength="2000" rows="6" placeholder="Ceritakan apa yang kamu lihat atau alami. Hindari dugaan dan kata-kata menghina." required></textarea>
      <div class="hint">Maksimal 2.000 karakter. Tidak perlu menuliskan detail yang membuatmu tidak nyaman.</div>

      <div class="checkbox-card">
        <input type="checkbox" id="anonymous" name="anonymous" value="1" checked>
        <label for="anonymous"><strong>Kirim secara anonim</strong><small>Nama dan kontak tidak akan diminta jika pilihan ini aktif.</small></label>
      </div>

      <div id="identity-fields" class="identity-fields hidden">
        <label for="reporter_name">Nama (opsional)</label>
        <input id="reporter_name" name="reporter_name" type="text" maxlength="80" autocomplete="name">
        <label for="reporter_contact">Kontak yang aman dihubungi (opsional)</label>
        <input id="reporter_contact" name="reporter_contact" type="text" maxlength="100" placeholder="Misalnya email atau nomor wali">
        <p class="hint">Isi hanya jika kamu nyaman dan memang diperlukan untuk tindak lanjut.</p>
      </div>

      <div class="privacy-note"><strong>Perhatikan keamananmu.</strong> Jangan mendekati konflik atau mencoba melerai sendiri. Jika kejadian sedang berlangsung atau ada yang terancam bahaya, segera cari guru, petugas keamanan sekolah, atau orang dewasa tepercaya.</div>
      <button class="button" type="submit">Kirim Laporan</button>
    </form>
  </section>

  <aside class="side-column">
    <section class="panel side-panel"><span class="icon">🤝</span><h3>Melapor itu langkah berani</h3><p>Laporan membantu sekolah memahami kejadian dan memberikan dukungan kepada pihak yang membutuhkan.</p></section>
    <section class="panel side-panel"><span class="icon">🔐</span><h3>Jaga privasi</h3><p>Jangan sertakan kata sandi, alamat rumah, nomor identitas, atau data pribadi orang lain. Jangan mengunggah atau menyebarkan rekaman kejadian.</p></section>
    <section class="panel side-panel"><span class="icon">ℹ️</span><h3>Informasi penting</h3><p>Formulir ini ditujukan kepada petugas sekolah yang ditunjuk. Hindari membalas perundungan atau ikut tawuran. Mintalah bantuan guru BK, wali kelas, atau orang dewasa tepercaya.</p></section>
  </aside>
</main>
<footer class="footer">RUANG AMAN · Website pelaporan dan edukasi sekolah</footer>
<script>
const anonymousBox = document.getElementById('anonymous');
const identityFields = document.getElementById('identity-fields');
function toggleIdentity() {
  identityFields.classList.toggle('hidden', anonymousBox.checked);
}
anonymousBox.addEventListener('change', toggleIdentity);
toggleIdentity();
</script>
</body>
</html>
