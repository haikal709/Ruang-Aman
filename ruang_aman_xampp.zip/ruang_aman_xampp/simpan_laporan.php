<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}
verify_csrf();

$allowed = ['Perundungan', 'Tawuran', 'Lainnya'];
$category = trim($_POST['category'] ?? '');
$incidentAt = trim($_POST['incident_at'] ?? '');
$location = trim($_POST['location'] ?? '');
$chronology = trim($_POST['chronology'] ?? '');
$anonymous = isset($_POST['anonymous']);
$name = trim($_POST['reporter_name'] ?? '');
$contact = trim($_POST['reporter_contact'] ?? '');

$errors = [];
if (!in_array($category, $allowed, true)) $errors[] = 'Pilih jenis kejadian yang tersedia.';
$date = DateTime::createFromFormat('Y-m-d\TH:i', $incidentAt);
if (!$date || $date->format('Y-m-d\TH:i') !== $incidentAt) $errors[] = 'Tanggal dan waktu kejadian tidak valid.';
if ($location === '' || mb_strlen($location) > 120) $errors[] = 'Lokasi wajib diisi (maksimal 120 karakter).';
if ($chronology === '' || mb_strlen($chronology) > 2000) $errors[] = 'Kronologi wajib diisi (maksimal 2.000 karakter).';
if (!$anonymous && (mb_strlen($name) > 80 || mb_strlen($contact) > 100)) $errors[] = 'Nama atau kontak terlalu panjang.';

if ($errors) {
    set_flash(implode(' ', $errors), 'error');
    header('Location: index.php#form-laporan');
    exit;
}
if ($anonymous) {
    $name = null;
    $contact = null;
} else {
    $name = $name !== '' ? $name : null;
    $contact = $contact !== '' ? $contact : null;
}

$stmt = $pdo->prepare('INSERT INTO reports (category, incident_at, location, chronology, is_anonymous, reporter_name, reporter_contact) VALUES (?, ?, ?, ?, ?, ?, ?)');
$stmt->execute([$category, $date->format('Y-m-d H:i:s'), $location, $chronology, $anonymous ? 1 : 0, $name, $contact]);

set_flash('Terima kasih. Laporan berhasil disimpan. Jika kamu masih merasa tidak aman, segera hubungi guru atau orang dewasa tepercaya.');
header('Location: index.php#form-laporan');
exit;
