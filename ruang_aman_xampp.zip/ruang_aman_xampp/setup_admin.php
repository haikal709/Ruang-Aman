<?php
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/db.php';

$count = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $count === 0) {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!preg_match('/^[A-Za-z0-9_.-]{4,40}$/', $username)) {
        $error = 'Username harus 4–40 karakter (huruf, angka, titik, garis bawah, atau tanda hubung).';
    } elseif (strlen($password) < 12) {
        $error = 'Password minimal 12 karakter.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)');
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
        set_flash('Akun admin berhasil dibuat. Hapus file setup_admin.php setelah ini.', 'success');
        header('Location: admin/login.php');
        exit;
    }
}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Setup Admin</title><link rel="stylesheet" href="style.css"></head>
<body class="plain-page"><main class="panel narrow">
<h2>Pengaturan Admin</h2>
<?php if ($count > 0): ?>
<div class="alert error">Akun admin sudah tersedia. Demi keamanan, halaman setup ini sudah dinonaktifkan. Hapus file setup_admin.php dari folder proyek.</div>
<a class="button" href="admin/login.php">Ke Login Admin</a>
<?php else: ?>
<p class="muted">Buat akun admin pertama. Gunakan password unik minimal 12 karakter.</p>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<label>Username</label><input name="username" required minlength="4" maxlength="40" autocomplete="username">
<label>Password</label><input name="password" type="password" required minlength="12" autocomplete="new-password">
<button class="button" type="submit">Buat Admin</button>
</form>
<?php endif; ?>
</main></body></html>
