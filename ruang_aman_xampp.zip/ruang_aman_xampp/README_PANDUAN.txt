RUANG AMAN - WEBSITE LAPORAN PERUNDUNGAN & TAWURAN
=================================================

TEKNOLOGI
- PHP + MySQL (XAMPP)
- HTML, CSS, JavaScript
- Dashboard admin dengan login

CARA MENJALANKAN DI XAMPP
1. Ekstrak folder "ruang_aman_xampp".
2. Pindahkan folder "ruang_aman_xampp" ke:
   C:\xampp\htdocs\
3. Buka XAMPP Control Panel.
4. Klik Start pada Apache dan MySQL.
5. Buka browser: http://localhost/phpmyadmin
6. Pilih tab Import.
7. Pilih file database.sql dari folder proyek, lalu klik Import/Go.
   File SQL akan membuat database bernama "ruang_aman".
8. Buka: http://localhost/ruang_aman_xampp/setup_admin.php
9. Buat username admin dan password minimal 12 karakter.
10. Setelah akun berhasil dibuat, HAPUS file setup_admin.php dari folder proyek.
11. Buka website:
    http://localhost/ruang_aman_xampp/
12. Login petugas:
    http://localhost/ruang_aman_xampp/admin/login.php

JIKA DATABASE TIDAK TERHUBUNG
- Pastikan MySQL di XAMPP berstatus Running.
- Periksa config.php. Pengaturan standar XAMPP:
  DB_HOST = localhost
  DB_NAME = ruang_aman
  DB_USER = root
  DB_PASS = (kosong)
- Jika MySQL kamu memakai password, isi DB_PASS sesuai password tersebut.

FITUR
- Form laporan perundungan, tawuran, atau kategori lainnya.
- Laporan anonim (nama dan kontak tidak disimpan jika anonim dipilih).
- Penyimpanan laporan ke MySQL.
- Login admin menggunakan password hash.
- Dashboard daftar laporan dan filter status.
- Detail kronologi laporan.
- Status: Menunggu, Diproses, Selesai.
- Validasi input, prepared statements, escaping output, dan CSRF token.

CATATAN KEAMANAN PENTING
- Ini versi proyek/pengembangan lokal untuk dijalankan di komputer sekolah.
- Jangan langsung mempublikasikan ke internet sebelum ditinjau dan diamankan oleh guru/pengelola IT.
- Untuk penggunaan sungguhan, sekolah harus menunjuk petugas yang bertanggung jawab, membatasi akses dashboard, membuat backup aman, menerapkan HTTPS, perlindungan spam/rate limit, dan prosedur tindak lanjut yang menjaga kerahasiaan.
- Jangan meminta pelapor mengunggah foto/video atau data sensitif.
- Jika kejadian sedang berlangsung atau ada ancaman keselamatan, pengguna harus segera menghubungi guru, petugas keamanan sekolah, atau orang dewasa tepercaya. Form ini bukan layanan darurat.
