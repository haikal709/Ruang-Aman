<?php
// Sesuaikan jika MySQL XAMPP kamu memakai password.
define('DB_HOST', 'localhost');
define('DB_NAME', 'ruang_aman');
define('DB_USER', 'root');
define('DB_PASS', '');
